<footer class="main-footer">
    <strong>Copyright &copy; {{Carbon\carbon::now()->year}} <a href="http://tyd.or.tz/" target="_blank" >TYD InnovationIncubator</a>.</strong> All rights
    reserved.
</footer>
