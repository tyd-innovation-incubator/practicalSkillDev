<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'PRASDEL') }}</title>

    <!-- Styles -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    		<!-- Ionicons -->

        <link href="{{ asset('plugins/css/plugins.css')}}" rel="stylesheet">

    		<link href="{{ asset('fonts/ionicons/css/ionicons.min.css')}}" rel="stylesheet">
    		<!-- Owl Carousel -->
    		<link href="css/owl.carousel.css" rel="stylesheet">
    		<link href="css/owl.theme.default.css" rel="stylesheet">
    		<!-- Animate.css -->
    		<link href="{{ asset('css/animate.min.css')}}" rel="stylesheet">
    		<!--Magnific Popup -->
    		<link href="{{ asset('css/magnific-popup.css')}}" rel="stylesheet">
    		<!--Tagsinput CSS -->
    		<link href="{{ asset('css/tagsinput.css')}}" rel="stylesheet">
    		<!-- Style.css -->
    		<link href="{{ asset('css/newstyle.css')}}" rel="stylesheet">

    <link href="{{ asset('css/bio.css') }}" rel="stylesheet">
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <link href="{{ asset('css/materialdesignicons.min.css') }}" rel="stylesheet">

    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
    <link href="{{ asset('css/sweetalert.css') }}" rel="stylesheet">


    <link rel="stylesheet" href="{{ asset('/css/admin/bower_components/font-awesome/css/font-awesome.min.css')}}">

    <link rel="stylesheet" href="{{ asset('/css/admin/bower_components/bootstrap/dist/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{ asset('/css/admin/bower_components/bootstrap/dist/css/bootstrap.min.css')}}">

    @section('headSection')

      @show
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="{{ asset('js/bio.js') }}"></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style media="screen">
  .dashboard li{
    display:block;
  },
  .panel-title{

  }
</style>

<script>
$(document).ready(

    function iniciar(){
    $('.follow').on("click", function(){
        $('.follow').css('background-color','#34CF7A');
        $('.follow').html('<div class="icon-ok"></div> Following');
    });
    }

);
</script>

</head>
<body>


  		<!-- Header -->
  		<header class="header">
  			<div class="container clearfix">
  				<div class="header-inner flex space-between items-center">
  					<div class="left">
  						<div class="logo"><a href="/"><img src="/image/LogoMakr_4WXAYZ.png"  style="width:300px;"alt="JobPress" class="img-responsive"></a></div>
  					</div> <!-- end .left -->
  					<div class="right flex space-between no-column items-center">
                @if (Auth::guest())
                <div class="navigation">
    							<nav class="main-nav">
    								<ul class="list-unstyled">
    									<li class="active"><a href="/">Home</a></li>
    									<li><a href="/about">About</a></li>
                      <li >
                        <a href="/posts">Soft Skill</a>

                      </li>
    									<li class="menu-item-has-children">
    										<a href="candidates-listing.html">Candidates</a>
    										<ul>
    											<li><a href="/Traininglist">Training Listing</a></li>
    											<li><a href="/postresume">Post a Resume</a></li>
    											<li><a href="/dashboard">Candidate Dashboard</a></li>
    										</ul>
    									</li>
    									<li class="menu-item-has-children">
    										<a href="companies-listing.html">Companies</a>
    										<ul>
    											<li><a href="/companies-list">Browse Companies</a></li>
    											<li><a href="/Traininglist/create">Post a job</a></li>
    											<li><a href="/EmployerDashboard">Employer Dashboard</a></li>
    										</ul>
    									</li>

    									<li class="menu-item-has-children">
    										<a href="#0">Pages</a>
    										<ul>
    											<li><a href="/Help">Help Tabs</a></li>
    											<li><a href="/contact">Contact Us</a></li>
    											<li><a href="/pricingplan">Pricing plans</a></li>
    										</ul>
    									</li>
    								</ul>
    							</nav> <!-- end .main-nav -->
    							<a href="#" class="responsive-menu-open"><i class="ion-navicon"></i></a>
    						</div> <!-- end .navigation -->
    						<div class="button-group-merged flex no-column">
                <a href="/Traininglist/create" class="button">Post a Job</a>
  							<a href="/register" class="button" >Sign Up</a>
                @else
                <div class="navigation">
                  <nav class="main-nav">
                    <ul class="list-unstyled">
                      <li class="active"><a href="/">Home</a></li>
                      <li><a href="/about">About</a></li>
                      <li >
                        <a href="/posts">Soft Skill</a>

                      </li>
                      <li class="menu-item-has-children">
                        <a href="candidates-listing.html">Candidates</a>
                        <ul>
                          <li><a href="/Traininglist">Training Listing</a></li>
                          <li><a href="/postresume">Post a Resume</a></li>
                          <li><a href="/dashboard">Candidate Dashboard</a></li>
                        </ul>
                      </li>
                      <li class="menu-item-has-children">
                        <a href="companies-listing.html">Companies</a>
                        <ul>
                          <li><a href="/companies-list">Browse Companies</a></li>
                          <li><a href="/Traininglist/create">Post a job</a></li>
                          <li><a href="/EmployerDashboard">Employer Dashboard</a></li>
                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a href="#0">Pages</a>
                        <ul>
                          <li><a href="/Help">Help Tabs</a></li>
                          <li><a href="/contact">Contact Us</a></li>
                          <li><a href="/pricingplan">Pricing plans</a></li>
                        </ul>
                      </li>
                    </ul>
                  </nav> <!-- end .main-nav -->
                  <a href="#" class="responsive-menu-open"><i class="ion-navicon"></i></a>
                </div> <!-- end .navigation -->
                <div class="button-group-merged flex no-column">

                <div class="account-info-top flex items-center no-column">
                    <a href="#0" class="notification-icon"><i class="ion-android-notifications"></i></a>
                    <a href="/dashboard" class="profile-button flex space-between items-center no-column no-wrap"><span>Hi!</span>{{ Auth::user()->name }}<img src="image/avatar01.jpg" alt="avatar" class="img-responsive"></a>
                  </div> <!-- end .account-info-top -->

                @endif

  						</div> <!-- end .button-group-merged -->
  					</div> <!-- end .right -->
  				</div> <!-- end .header-inner -->
  			</div> <!-- end .container -->
  		</header> <!-- end .header -->

  		<!-- Responsive Menu -->
  		<div class="responsive-menu">
  			<a href="#" class="responsive-menu-close"><i class="ion-android-close"></i></a>
  			<nav class="responsive-nav"></nav> <!-- end .responsive-nav -->
  		</div> <!-- end .responsive-menu -->

<!--
  <div class="page text-center">
    <header class="page-head slider-menu-position">

        <div class="rd-navbar-wrap">
          <nav data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static" class="rd-navbar container rd-navbar-floated rd-navbar-dark rd-navbar-dark-transparent" data-lg-auto-height="true" data-md-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-stick-up="true">
            <div class="rd-navbar-inner">
              <div class="rd-navbar-panel">
                <button data-rd-navbar-toggle=".rd-navbar, .rd-navbar-nav-wrap" class="rd-navbar-toggle"><span></span></button>
                <button data-rd-navbar-toggle=".rd-navbar, .rd-navbar-right-buttons" class="rd-navbar-right-buttons-toggle"><span></span></button>
                <div class="rd-navbar-brand"><a href="index.html"><img width='300' height='40' src='/image/LogoMakr_4WXAYZ.png' alt=''/></a></div>
              </div>
              <div class="rd-navbar-menu-wrap">
                <div class="rd-navbar-nav-wrap">
                  <div class="rd-navbar-mobile-scroll">
                    <div class="rd-navbar-mobile-brand"><a href="index.html"><img width='218' height='35' src='image/LOGO.png' alt=''/></a></div>
                    @if (Auth::guest())
                    <ul class="rd-navbar-nav">
                    										<li class="active"><a href="/"><span>Home</span></a></li>
                    										<li class=""><a href="/vacancies"><span>Vacancies</span></a></li>
                                        <li class=""><a href="/posts"><span>Skills/Tips</span></a></li>
                    										<li class=""><a href="/company/login"><span>Employers</span></a></li>
                                        <li><a href="{{ route('login') }}">Training Seeker</a></li>
                    									</ul>

                    @else
                    <ul class="rd-navbar-nav">
                                        <li class="active"><a href="/"><span>Home</span></a></li>
                                        <li class=""><a href="/vacancies"><span>Vacancies</span></a></li>
                                        <li class=""><a href="/posts"><span>Skills/Tips</span></a></li>
                                        <li class=""><a href="/company/login"><span>Employers</span></a></li>
                                        <li>
                                            <a href="#">Categories</a>
                                            <ul class="rd-navbar-dropdown">
                                              <li class="text-primary"><a href="/trainings/all">All</a></li>
                                              <li class="text-primary"><a href="jobs/employment/freelance.html">Freelance</a></li>
                                              <li class="text-primary"><a href="jobs/employment/full-time.html">Full Time</a></li>
                                              <li class="text-primary"><a href="jobs/employment/internship.html">Internship</a></li>
                                              <li class="text-primary"><a href="jobs/employment/part-time.html">Part Time</a></li>
                                              <li class="text-primary"><a href="jobs/employment/temporary.html">Temporary</a></li>
                                            </ul>
                                        </li>


                                        <li><a href="/dashboard">Dashboard</a></li>
                                          <li class="dropdown">
                                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                                  {{ Auth::user()->name }} <span class="caret"></span>
                                              </a>

                                              <ul class="rd-navbar-dropdown" role="menu">
                                                  <li>
                                                      <a href="{{ route('logout') }}"
                                                          onclick="event.preventDefault();
                                                                   document.getElementById('logout-form').submit();">
                                                          Logout
                                                      </a>

                                                      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                          {{ csrf_field() }}
                                                      </form>
                                                   </li>
                                              </ul>
                                          </li>
                                      </ul>


                    <ul class="nav navbar-nav navbar-right">


                    @endif
                  </div>
                </div>


              </div>
            </div>
          </nav>
        </div>
      </header>


    -->


      @yield('content')

</div>
<!--
<footer class="section-relative section-top-66 section-bottom-34 page-footer bg-gray-darkest">
    <div class="shell">
      <div class="range range-sm-center text-md-left">
        <div class="cell-sm-12 cell-md-12">
          <div class="range range-xs-center text-left">
            <div class="cell-xs-4 cell-md-2 cell-sm-6 offset-top-50 offset-md-top-0 text-left">
              <h6 class="text-uppercase text-spacing-60 font-default text-white">Different Sector</h6>
              <div class="reveal-block">
                <div class="reveal-inline-block">
                                      <ul class="list list-unstyled list-inline-primary">
                                                                    <li class="text-primary">
                        <a href="jobs/sector/sales-and-marketing.html">Sales and Marketing</a>
                      </li>
                                                                  <li class="text-primary">
                        <a href="jobs/sector/manufacturing-and-production.html">Manufacturing And Production</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/sector/education.html">Education</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/sector/food-services.html">Food Services</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/sector/construction.html">Construction</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/sector/architecture-and-engineering.html">Architecture And Engineering</a>
                      </li>
                                          <li class="text-primary">
                      <a href="jobs/sector/all.html">All Sectors</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="cell-xs-4 cell-md-3 cell-sm-6 offset-top-50 offset-md-top-0 cell-md-push-3 text-left">
              <h6 class="text-uppercase text-spacing-60 font-default text-white">favourites Category</h6>
              <div class="reveal-block">
                <div class="reveal-inline-block">
                                      <ul class="list list-unstyled list-inline-primary">
                                                                    <li class="text-primary">
                        <a href="jobs/category/website-developer.html">Website Developer</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/category/machinist.html">Machinist</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/category/police-officer.html">Police Officer</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/category/biologist.html">Biologist</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/category/personal-injury-paralegal.html">Personal Injury Paralegal</a>
                      </li>
                                                                    <li class="text-primary">
                        <a href="jobs/category/front-end-developer.html">Front End Developer</a>
                      </li>
                                        </ul>
                </div>
              </div>
            </div>


            <div class="cell-xs-4 cell-md-3 cell-sm-6 offset-top-50 offset-md-top-0 cell-md-push-3 text-left">
              <h6 class="text-uppercase text-spacing-60 font-default text-white">Available Types</h6>
              <div class="reveal-block">
                <div class="reveal-inline-block">
                  <ul class="list list-unstyled list-inline-primary">
                    <li class="text-primary"><a href="/trainings/all">All</a></li>
                    <li class="text-primary"><a href="jobs/employment/freelance.html">Freelance</a></li>
                    <li class="text-primary"><a href="jobs/employment/full-time.html">Full Time</a></li>
                    <li class="text-primary"><a href="jobs/employment/internship.html">Internship</a></li>
                    <li class="text-primary"><a href="jobs/employment/part-time.html">Part Time</a></li>
                    <li class="text-primary"><a href="jobs/employment/temporary.html">Temporary</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="cell-xs-4 cell-md-3 cell-sm-6 offset-top-50 offset-md-top-0 cell-md-push-3 text-left">
              <h6 class="text-uppercase text-spacing-60 font-default text-white">Quick Links</h6>
              <div class="reveal-block">
                <div class="reveal-inline-block">
                  <ul class="list list-unstyled list-inline-primary">
                    <li class="text-primary"><a href="/aboutus">About Us</a></li>
                    <li class="text-primary"><a href="/skills">Blog</a></li>
                    <li class="text-primary"><a href="/faq">FAQ</a></li>
                    <li class="text-primary"><a href="/contact">Contact Us</a></li>
                    <li class="text-primary"><a href="/privacy-policy">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          </div>
          <div class="range range-xs-center">
            <div class="cell-md-12 offset-top-50 offset-md-top-0 text-left">
              <ul class="list-inline list-inline-sm reveal-inline-block post-meta text-dark list-inline-primary pull-right" style="margin-top:8px;">
                <li><a href="#"><span class="fa fa-facebook fa-2x"></span></a></li>
                <li><a href="#"><span class="fa fa-twitter fa-2x"></span></a></li>
                <li><a href="#"><span class="fa fa-linkedin fa-2x"></span></a></li>
                <li><a href="#"><span class="fa fa-google-plus fa-2x"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
        <p style="color:white; margin-left:300px; font-size:1.2em;" >© 2018 - All Rights with TYDInnovationIncubatordeveloper</p>

      </div>

  </footer>
-->

<!-- Footer Section Start -->
<footer class="footer">
  <div class="row lg-menu">
    <div class="container">
      <div class="col-md-4 col-sm-4">
        <img src="/image/LogoMakr_4WXAYZ.png"  style="width:300px;" class="img-responsive" alt="" />
      </div>
      <div class="col-md-8 co-sm-8 pull-right">
        <ul>
          <li><a href="/" title="">Home</a></li>
          <li><a href="/posts" title="">Soft Skills</a></li>
          <li><a href="/Help" title="">FAQ</a></li>
          <li><a href="/contact" title="">Contact Us</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="row no-padding">
    <div class="container">

      <div class="col-md-3 col-sm-12">
        <div class="footer-widget">
        <h3 class="widgettitle widget-title">About PRASDEL</h3>
        <div class="textwidget">
        <p>PRACTICAL SKILL DEVELOPMENT LINK</p>
        <p>Ilala Bungoni<br>
        Dar Es Salaa,</p>
        <p><strong>Email:</strong> Support@prasdel.co.tz</p>
        <p><strong>Call:</strong> <a href="tel:0753070202">0753070202</a></p>
        <ul class="footer-social">
          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#"><i class="fa fa-instagram"></i></a></li>
          <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
        </ul>
        </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-4">
        <div class="footer-widget">
          <h3 class="widgettitle widget-title">All Navigation</h3>
          <div class="textwidget">
            <div class="textwidget">
            <ul class="footer-navigation">
              <li><a href="" title="">Front-end Design</a></li>
              <li><a href="" title="">Android Developer</a></li>
              <li><a href="" title="">CMS Development</a></li>
              <li><a href="" title="">PHP Development</a></li>
              <li><a href="" title="">IOS Developer</a></li>
              <li><a href="" title="">Iphone Developer</a></li>
            </ul>
          </div>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-4">
        <div class="footer-widget">
          <h3 class="widgettitle widget-title">All Categories</h3>
          <div class="textwidget">
            <ul class="footer-navigation">
              <li><a href="" title="">Front-end Design</a></li>
              <li><a href="" title="">Android Developer</a></li>
              <li><a href="" title="">CMS Development</a></li>
              <li><a href="" title="">PHP Development</a></li>
              <li><a href="" title="">IOS Developer</a></li>
              <li><a href="" title="">Iphone Developer</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="col-md-3 col-sm-4">
        <div class="footer-widget">
          <h3 class="widgettitle widget-title">Connect Us</h3>
          <div class="textwidget">
          <form class="footer-form">
            <input type="text" class="form-control" placeholder="Your Name">
            <input type="email" class="form-control" placeholder="Email">
            <textarea class="form-control" placeholder="Message"></textarea>
            <button type="submit" class="btn btn-primary">Send</button>
          </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row copyright">
    <div class="container">
      <p>Copyright <a href="http://tyd.or.tz"> TYDInnovationIncubator </a>© 2017. All Rights Reserved

       </p>
    </div>
  </div>
</footer>
<div class="clearfix"></div>
<!-- Footer Section End -->

    <!-- Scripts -->
    @section('footerSection')

      @show
      <!-- Scripts -->
      <!-- jQuery -->
      <script src="{{ asset('js/jquery-3.1.1.min.js')}}"></script>
      <!-- Bootstrap -->
      <script src="{{ asset('js/bootstrap.min.js')}}"></script>
      <!-- google maps -->
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAy-PboZ3O_A25CcJ9eoiSrKokTnWyAmt8"></script>
      <!-- Owl Carousel -->
      <script src="{{ asset('js/owl.carousel.min.js')}}"></script>
      <!-- Wow.js -->
      <script src="{{ asset('js/wow.min.js')}}"></script>
      <!-- Typehead.js -->
      <script src="{{ asset('js/typehead.js')}}"></script>
      <!-- Tagsinput.js -->
      <script src="{{ asset('js/tagsinput.js')}}"></script>
      <!-- Bootstrap Select -->
      <script src="{{ asset('js/bootstrap-select.js')}}"></script>
      <!-- Waypoints -->
      <script src="{{ asset('js/jquery.waypoints.min.js')}}"></script>
      <!-- CountTo -->
      <script src="{{ asset('js/jquery.countTo.js')}}"></script>
      <!-- Isotope -->
      <script src="{{ asset('js/isotope.pkgd.min.js')}}"></script>
      <script src="{{ asset('js/imagesloaded.pkgd.min.js')}}"></script>
      <!-- Magnific-Popup -->
      <script src="{{ asset('js/jquery.magnific-popup.js')}}"></script>
      <!-- Scripts.js -->
      <script src="{{ asset('js/scripts.js')}}"></script>


    <script src="{{ asset('js/scripts.min.js')}}"></script>
  <script src="{{asset('js/main.js')}}"></script>
  <!--<script src="http://www.powerjob.in/js/toastr.min.js"></script>-->
  <script src="{{asset('js/sweetalert.min.js')}}"></script>
      <script>function subcategory(a){$.ajax({type:"GET",url:"http://www.powerjob.in/company/posts/category/"+a,success:function(a){$("#get_subcategory").html(a),$("#get_subcategory").
    <script src="{{ asset('js/app.js') }}"></script>

</body>
</html>
