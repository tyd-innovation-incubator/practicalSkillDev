
@extends('layouts.admin.app')
@section('main-content')
<div class="wrapper">

  <!-- Left side column. contains the logo and sidebar -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          ADMIN HOME PAGE
          <small>it all starts here</small>
        </h1>
      </section>

    </div>
  <!-- /.content-wrapper -->

</div>

@endsection
