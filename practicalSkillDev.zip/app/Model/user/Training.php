<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class Training extends Model
{
    //
}
