<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class Intro extends Model
{
    //
}
