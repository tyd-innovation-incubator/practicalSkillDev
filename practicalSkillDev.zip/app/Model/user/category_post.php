<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class category_post extends Model
{
    //
}
